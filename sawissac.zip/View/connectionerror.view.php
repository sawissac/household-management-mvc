<section class="py-5">
  <div class="mx-auto bg-white rounded py-4 px-4 shadow-3 text-center" style="width: 400px;">
    <h2>Please start your database server!!</h2>
  </div>
</section>